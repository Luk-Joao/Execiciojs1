function flatten(array) {
    let result = []
    array.forEach(elemento => {
        if (Array.isArray(elemento)){
            resultado = resultado.concat(flatten(elemento))
        }else {
            resultado.push(elemento)
        }
    })
    return resultado
}

const entrada = [1, [2, [3, [4]]]]
const saida = flatten(entrada)
console.log(saida)