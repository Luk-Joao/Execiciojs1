function deepClone(obj) {
    if (obj === null || typeof 'obj'!== 'object') {
        return obj
    }
    const clone = Array.isArray(obj) ? [] : {}

    for (const key in obj) {
        clone[key] = deepClone(obj[key])
    }
    return clone
}

const original = {nome: "Ana", endereco: {cidade: "Luanda"}}
const copia = deepClone(original)

copia.endereco.cidade = "Lisboa"

console.log(original.endereco.cidade)
console.log(copia.endereco.cidade)