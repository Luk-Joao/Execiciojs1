const valor = prompt("Digite os valores separados por virgula:")
const lista = valor.split(',').map(num =>Number(num.trim()));

const repeticao = {}

lista.forEach(num => {
    repeticao[num] = 
    (repeticao[num] || 0) +1;
    }) 

const listaRepeticao = Object.entries(repeticao)
listaRepeticao.sort((a,b) => b[1] - a[1])

const top3 = listaRepeticao.slice(0, 3)
console.log(top3)