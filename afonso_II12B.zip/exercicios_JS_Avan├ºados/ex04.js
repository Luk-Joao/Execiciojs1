function objeto(obj, prefixo = '') {
    let result = {}

    for (const key in obj) {
        const navakey = prefixo ? '${prefixo}.${key}' : key
        if (typeof obj[key] === 'object' && obj[key] !== null && !Array.isArray(obj[key])) {
            Object.assign(result, flattenObject(obj[key], novaKey))
        }else {
            result[novaKey] = obj[key]
        }
    }
    return result
}

const entrada = {usuario:{nome: "Ana", idade: 20}}
const outraEntrada = flattenObject(entrada)

console.log(outraEntrada)