async function 
executePromisesInOrder(promises) {
    const results = []
    for (const promiseFunc of promises) {
        const result = await
promiseFunc()
        results.push(result)
    }
    return results
}

async function teste() {
    const f1 = () => new Promise(r => setTimeout(() => r('primeira'), 1000))
    const f2 = () => new Promise(r => setTimeout(() => r('segunda'), 500))

    const results = await 
    executePromisesInOrder([f1, f2])
    console.log(results)
}