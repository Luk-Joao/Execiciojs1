Nome: João Lufua Afonso.
Nº 9
Turma II12B 