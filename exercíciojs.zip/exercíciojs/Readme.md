# Informações do Aluno
**Nome:** Lukoki joao
**Turma:** II12B
**Número de Aluno:** 15
